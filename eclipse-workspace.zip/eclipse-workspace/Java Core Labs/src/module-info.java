module javaCoreLabs {
}