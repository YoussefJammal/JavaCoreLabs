package com.javaoo.calculators;

public class CalculatorDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BasicCalculator basicCalculator = new BasicCalculator();
		double x = basicCalculator.add(7, 8);
		
		System.out.println(x);
	}

}
