package com.javaoo.calculators;

public class ScientificCalculator {
	
	
	// Creating the value for PI
	public static final double PI = 3.14159;
	
	// Creating a short term memory for the most recently calculated value
	private double holdValue;
		
	// Creating the public methods exponential, log, and affecting the holdValue
	public double exp(double x){
		return Math.exp(x);
	}
	
	public double log(double x) {
		return Math.log(x);
	}
	
	// A setter and getter were created to influence the value
	public double getValueFromMemory() {
		return holdValue;
	}

	public void putValueInMemory(double newHoldValue) {
		holdValue = newHoldValue;
	}

}
