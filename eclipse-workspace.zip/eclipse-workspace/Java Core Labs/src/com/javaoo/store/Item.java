package com.javaoo.store;

public class Item {
	
	// Attribute declaration
	private String title;
	private double price;
	private int quantity;
	
	// Setter and Getter declaration
	public String getTitle() {
		return title;
	}
	public void setTitle(String newTitle) {
		title = newTitle;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double newPrice) {
		price = newPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int newQuantity) {
		quantity = newQuantity;
	}
	
	// Constructors
	Item(){		}
	
	Item(String newTitle, double newPrice, int newQuantity){
		setTitle(newTitle);
		setPrice(newPrice);
		setQuantity(newQuantity);
	}

}
