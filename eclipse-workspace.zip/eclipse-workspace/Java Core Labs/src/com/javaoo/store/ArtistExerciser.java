package com.javaoo.store;

import java.util.SortedSet;
import java.util.TreeSet;

public class ArtistExerciser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Artist hotPlate = new Artist("hot plate");
		SortedSet<String> instruments1 = new TreeSet<String>();
		instruments1.add("Piano");
		instruments1.add("Clarinet");
		instruments1.add("Hurdy");
		instruments1.add("Gurdy");
		instruments1.add("Tuba");
		
		SortedSet<String> instruments2 = new TreeSet<String>();
		instruments2.add("Guitar");
		instruments2.add("Bass");
		instruments2.add("Violin");
		instruments2.add("Flute");
		instruments2.add("Drums");
		
		hotPlate.addMember("Tom", instruments1);
		hotPlate.addMember("Steve", instruments2);
		
		System.out.println(hotPlate.getMembers());
		System.out.println(hotPlate.getInstruments("Tom"));
		System.out.println(hotPlate.getInstruments("Steve"));

	}

}
