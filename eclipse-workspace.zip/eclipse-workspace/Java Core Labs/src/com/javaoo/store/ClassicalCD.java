package com.javaoo.store;

import java.util.Date;

public class ClassicalCD extends Item{
	
	// Attribute declaration
	String composer;
	String[] performers = new String[5];
	String recordingLocation;
	Date releaseDate;
	

	// Setter and Getter declaration
	public String getComposer() {
		return composer;
	}
	public void setComposer(String newComposer) {
		composer = newComposer;
	}
	public String getRecordingLocation() {
		return recordingLocation;
	}
	public void setRecordingLocation(String newRecordingLocation) {
		recordingLocation = newRecordingLocation;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date newReleaseDate) {
		releaseDate = newReleaseDate;
	}
	
	// Adding perfomers
	private int performerCount = 0;
	
	public void addPerformer(String[] performerNameArray) {
		
		for(String performerName:performerNameArray) {
			if(performerCount <= performers.length) {
				performers[performerCount] = performerName;
				performerCount++;
			}
			
			else {
				System.out.println("Above maximum number of performers");
			}
		}
		
	}
	
	public void showPerformers() {
		for(int x = 0; x <= performerCount; x++) {
			System.out.print(performers[x] + " ");
		}
	}
	
	// Constructor
	public ClassicalCD(String newTitle, double newPrice, int newQuantity, String newComposer, String[] newPerformers, String newRecordingLocation, Date newReleaseDate){
		super(newTitle, newPrice, newQuantity);
		setComposer(newComposer);
		setRecordingLocation(newRecordingLocation);
		setReleaseDate(newReleaseDate);
		addPerformer(newPerformers);
	}
	
}
