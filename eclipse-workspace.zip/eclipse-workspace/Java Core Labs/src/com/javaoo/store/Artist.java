package com.javaoo.store;

import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class Artist {
	
	// Attribute declaration
	private String name;
	private SortedSet<String> memberNames;
	private Map<String, SortedSet<String>> memberInstruments;

	// Setter and Getter declaration
	public String getName() {
		return name;
	}
	public void setName(String newName) {
		name = newName;
	}
	
	// Methods
	public void addMember(String name, SortedSet<String> instruments) {
		memberNames.add(name);
		memberInstruments.put(name, instruments);
	}
	
	public SortedSet<String> getMembers(){
		return memberNames;
	}
	
	public SortedSet<String> getInstruments(String name){
		SortedSet<String> instrumentSet = memberInstruments.get(name);
		
		return instrumentSet;
	}
	
	// Constructors
	public Artist() {
		memberNames = new TreeSet<>();
		memberInstruments = new TreeMap<>();
		
	}
	
	public Artist(String newName){
		this();
		setName(newName);
	}

}
