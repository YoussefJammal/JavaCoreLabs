package com.javaoo.store.drivers;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;

import com.javaoo.store.Book;

public class BookExerciser {	
	public static List<Book> readBookFromFile(String fileName) {
		List<Book> books = null;
		try(
			FileInputStream input = new FileInputStream(fileName);
			InputStreamReader reader = new InputStreamReader(input);
			LineNumberReader lineNumber = new LineNumberReader(reader);
			){
			books = new ArrayList<>();
			String line;
			while((line = lineNumber.readLine())!= null) {
				String title = line;
				String author = lineNumber.readLine();
				double price = Double.parseDouble(lineNumber.readLine());
				books.add(new Book(title, price, 5, author, null, "NON-FICTION"));
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
		return books;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String location = "C:\\Users\\Owner\\OneDrive\\Documents\\learn\\certificates and specializations\\Coursera\\Core Java\\Notes\\eclipse-workspace\\Java Core Labs\\src\\com\\javaoo\\store\\book.txt";
		List<Book> books = readBookFromFile(location);
		for(Book book:books) {
			System.out.println(book.getTitle());
		}
	}

}
