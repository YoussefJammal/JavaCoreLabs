package com.javaoo.store.drivers;

import java.util.Date;

import com.javaoo.store.Artist;
import com.javaoo.store.Book;
import com.javaoo.store.CD;
import com.javaoo.store.ClassicalCD;
import com.javaoo.store.Inventory;
import com.javaoo.store.Item;

public class InventoryDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Item[] myInventory = new Item[50];
		
		myInventory[0] = new Book("Godzilla on acid", 10.99, 4, "Saint Josephina I", "Christ Editors", "spiritual but not religious");
		myInventory[1] = new Book("Godzilla on steroids", 11.99, 3, "Saint Josephina II", "Christ Editors", "spiritual");
		myInventory[2] = new Book("Godzilla on shrooms", 12.99, 2, "Saint Josephina III", "Christ Editors", "religious");
		myInventory[3] = new Book("Godzilla on weed", 13.99, 1, "Saint Josephina IV", "Christ Editors", "spiritual and religious");
		myInventory[4] = new Book("Godzilla on molly", 14.99, 5, "Saint Josephina V", "Christ Editors", "spirituality meets religious");
		myInventory[5] = new CD("Godzilla and the beatles meet", 12.95, 8, new Artist("GZ and BT"), new Date("07/08/2060"));
		
		String[] performers = {"Mastix", "Jabs", "Chichoz", "krissiz", "Toumz"};
		
		myInventory[6] = new ClassicalCD("Godzilla and Youss", 25.99, 2, "Joseph Seeds", performers, "Jal El Deon", new Date("01/01/2022"));
		
		Inventory.produceReport(myInventory[6]);
		
	}

}
