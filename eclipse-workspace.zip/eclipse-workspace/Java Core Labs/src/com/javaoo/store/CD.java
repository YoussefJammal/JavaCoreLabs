package com.javaoo.store;

import java.util.Date;

public class CD extends Item{
	
	// Attribute declaration
	Artist artist;
	Date releaseDate;

	// Setter and Getter declaration
	public Artist getArtist() {
		return artist;
	}
	public void setArtist(Artist newArtist) {
		artist = newArtist;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date newReleaseDate) {
		releaseDate = newReleaseDate;
	}
	
	// Constructor
	public CD(String newTitle, double newPrices, int newQuantity, Artist newArtist, Date newReleaseDate){
		super(newTitle, newPrices, newQuantity);
		setArtist(newArtist);
		setReleaseDate(newReleaseDate);
	}

}
