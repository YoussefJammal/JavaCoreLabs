package com.javaoo.store;

public class Inventory{
	
	public static void produceReport(Item obj) {
		
		System.out.println(obj.getTitle());
		System.out.println(obj.getPrice());
		System.out.println(obj.getQuantity());
	}

}
