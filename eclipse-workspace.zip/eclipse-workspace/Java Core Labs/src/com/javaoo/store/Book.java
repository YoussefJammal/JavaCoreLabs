package com.javaoo.store;

public class Book extends Item{
	
	// Attribute declaration
	private String author;
	private String publisher;
	private String category;

	// Setter and Getter declaration
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String newAuthor) {
		author = newAuthor;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String newPublisher) {
		publisher = newPublisher;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String newCategory) {
		category = newCategory;
	}
	
	// Constructors
	
	public Book(String newTitle, double newPrice, int newQuantity, String newAuthor, String newPublisher, String newCategory){
		super(newTitle, newPrice, newQuantity);
		setAuthor(newAuthor);
		setPublisher(newPublisher);
		setCategory(newCategory);
	}

}
