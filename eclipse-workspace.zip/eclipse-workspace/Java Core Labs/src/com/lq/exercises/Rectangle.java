package com.lq.exercises;

public class Rectangle extends Shape implements TwoDimensional {
	
	// Attributes
	private double length;
	private double width;
	
	// Setters and Getters
	public double getLength() {
		return length;
	}
	public void setLength(double newLength) {
		length = newLength;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double newWidth) {
		width = newWidth;
	}
	
	public Rectangle(String newName, String newColor, double newLength, double newWidth) {
		super(newName, newColor);
		setLength(newLength);
		setWidth(newWidth);
	}
	@Override
	public double getArea() {
		return length * width;
	}
	@Override
	public double getPerimeter() {
		return 2 * length + 2 * width;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Shape [length=");
		builder.append(getLength());
		builder.append(", width=");
		builder.append(getWidth());
		builder.append(", color=");
		builder.append(super.getColor());
		builder.append(", name=");
		builder.append(super.getName());
		builder.append("]");
		return builder.toString();
	}

}
