package com.lq.exercises;

public abstract class Shape {
	
	// Attributes	
	private String color;
	private String name;
	
	protected Shape(String newName, String newColor) {
		setColor(newColor);
		setName(newName);
	}
		
	// Setters and Getters
	public String getColor() {
		return color;
	}
	public void setColor(String newColor) {
		color = newColor;
	}
	public String getName() {
		return name;
	}
	public void setName(String newName) {
		name = newName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Shape [color=");
		builder.append(color);
		builder.append(", name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}
	
	

}
