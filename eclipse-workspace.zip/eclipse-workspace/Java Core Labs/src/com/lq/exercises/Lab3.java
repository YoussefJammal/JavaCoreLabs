package com.lq.exercises;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Exercise 1
		String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
		String[] monthsOfYear = {"January", "February", "March", "April", "May", "June", "July", "August", "Septembre", "October", "November", "December"};
		int lengthOfDays = daysOfWeek.length;
		System.out.println("standard for loop");
		for(int i = 0; i < lengthOfDays; i++) {
			System.out.println(daysOfWeek[i]);
		}
		System.out.println(" ");
		System.out.println("for-each loop");
		for(String j : daysOfWeek){
			System.out.println(j);
		}
		System.out.println(" ");
		System.out.println("reverse standard for loop");
		for(int i = --lengthOfDays; i >= 0; i--) {
			System.out.println(daysOfWeek[i]);
		}
		
		// Exercise 2
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("all even numbers between 1 and 20 without using continue and break");
		int i = 1;
		while(i++ <= 20){
			if(i%2==0) {System.out.println(i);}
		}
		System.out.println(" ");
		System.out.println("all odd numbers between 1 and 20 using continue and break");
		i = 1;
		while(i++ <= 20){
			if(i%2==0) {continue;}
			System.out.println(i-2);			
		}
		
		// Exercise 3
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("all numbers between 1 and 100 except numbers between 50 and 60");
		for(i = 1; i <= 100; i++) {
			if(i>=50 && i<= 60) {continue;}
			System.out.println(i);
		}
		
		// Exercise 4
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("Number of Days per month");
		i = 0;
		byte daysInTheMonth;
		while(i < 12) {
			switch(monthsOfYear[i]) {
			case "January":
			case "March":
			case "May":
			case "July":
			case "August":
			case "October":
			case "December":
				daysInTheMonth = 31;
				break;
			case "February":
				daysInTheMonth = 28;
				break;
			default:
				daysInTheMonth = 30;
			}
			System.out.println("There are " + daysInTheMonth + " days in the month of " + monthsOfYear[i]);
			i++;
		}
		
		// Challenging Exercise
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("challenging exercise");
		i = 0;
		while(i < 7){
			System.out.print(daysOfWeek[i] + "  ");
			i++;
		}
		System.out.println("  ");
		i = 1;
		for(int j = 1; j <= 7 * 5 + 1; j++) {
			if(j%7 == 1) {System.out.println("    ");}
			if(j <= 5) {System.out.print("          ");}
			else if(j <= 36){
				if(i < 10) {
				System.out.print(i + "         ");
				}
				else {System.out.print(i + "        ");}
				i++;
				}
		}
	}
}
