package com.lq.exercises;

public class Square extends Rectangle {
	
	Square(String newName, String newColor, double newSide){
		super(newName, newColor, newSide, newSide);
	}

}
