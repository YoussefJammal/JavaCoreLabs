package com.lq.exercises;

public class ExerciseShapes {

	public static void main(String[] args) {
		
		// Declaring the array with all shapes in it
		Shape[] s = new Shape[8];
		s[0] = new Rectangle("rectangle1", "green", 1, 1);
		s[1] = new Rectangle("rectangle2", "green", 1, 1);
		s[2] = new Square("square1", "green", 1);
		s[3] = new Square("square2", "green", 1);
		s[4] = new Cube("cube1", "green", 1);
		s[5] = new Cube("cube2", "green", 1);
		s[6] = new Box("box1", "green", 1,1,1);
		s[7] = new Box("box2", "green", 1,1,1);
		
		
		// Setting the color for the shapes
		for(Shape k:s) {
			k.setColor("blue");
		}
		
		/*
		 * 
		// Getting the volume from the shapes
		for(Shape k:s) {
			
			ThreeDimensional temp = (ThreeDimensional)k;
			System.out.println(temp.getVolume());
		}
		*
		*/
		
		// Declaring the array with all 2-D shapes in it
		TwoDimensional[] twoD = new TwoDimensional[3];
		twoD[0] = new Circle("cirlce3", "green", 1);
		twoD[1] = new Rectangle("rectangle3", "green", 1,1);
		twoD[2] = new Square("square3", "green", 1);
		
		// Getting the area and perimeter of 2-D shapes
		for(TwoDimensional k:twoD) {
			System.out.println(k.getArea());
			System.out.println(k.getPerimeter());
		}

	}

}
