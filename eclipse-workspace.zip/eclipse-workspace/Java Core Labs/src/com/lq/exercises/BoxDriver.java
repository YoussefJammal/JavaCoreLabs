package com.lq.exercises;

public class BoxDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box box1 = new Box("box1", "green", 5, 6, 7);
		Box box2 = new Box("box2", "green", 10);
		
		box1.boxPrint();
		box2.boxPrint();
		
		box1.setLength(3);
		box1.setWidth(4);
		box1.setHeight(5);
		
		double b1Vol = box1.getVolume();
		double b1SA = box1.getSurfaceArea();
		
		box1.boxPrint();
		
		System.out.println(b1Vol);
		System.out.println(b1SA);
		
		box1.setLength(-5);
		box1.boxPrint();
	}
}
