package com.lq.exercises;

public class Cube extends Box {

	Cube(String newName, String newColor, double c) {
		super(newName, newColor, c);	
		}
	 // Updating the side length, and in return update all the needed things
	public void setSide(double sideSize){
		if(sideSize != super.getLength()) {
			super.setLength(sideSize);
			super.setHeight(sideSize);
			super.setWidth(sideSize);
			super.update();
			
		}
	}
	
 // Updating the side length, and in return update all the needed things
	@Override
	public void setLength(double sideSize){
		if(sideSize != super.getLength()) {
			super.setLength(sideSize);
			super.setHeight(sideSize);
			super.setWidth(sideSize);
			super.update();
			
		}
	}
	
	 // Updating the side length, and in return update all the needed things
	@Override
	public void setHeight(double sideSize){
		if(sideSize != super.getLength()) {
			super.setLength(sideSize);
			super.setHeight(sideSize);
			super.setWidth(sideSize);
			super.update();
			
		}
	}
	
	 // Updating the side length, and in return update all the needed things
	@Override
	public void setWidth(double sideSize){
		if(sideSize != super.getLength()) {
			super.setLength(sideSize);
			super.setHeight(sideSize);
			super.setWidth(sideSize);
			super.update();
			
		}
	}
	
	public double getSide(){
		return super.getLength();
	}
}
