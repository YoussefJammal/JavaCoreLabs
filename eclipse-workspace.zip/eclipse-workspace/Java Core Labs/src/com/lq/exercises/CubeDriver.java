package com.lq.exercises;

public class CubeDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cube cube1 = new Cube("cube1", "green", 5);
		Cube cube2 = new Cube("cube2", "green", 8);
		
		System.out.println("The length of Cube 1 is " + cube1.getLength());
		System.out.println("The length of Cube 2 is " + cube2.getLength());
		
		System.out.println("The height of Cube 1 is " + cube1.getHeight());
		System.out.println("The height of Cube 2 is " + cube2.getHeight());
		
		System.out.println("The width of Cube 1 is " + cube1.getWidth());
		System.out.println("The width of Cube 2 is " + cube2.getWidth());
		
		System.out.println("The side size of Cube 1 is " + cube1.getSide());
		System.out.println("The side size of Cube 2 is " + cube2.getSide());
		
		cube1.setLength(20);
		cube1.boxPrint();
		
		cube1.setSide(40);
		cube1.boxPrint();
		
		cube2.boxPrint();
		
		cube2.setWidth(-5);
		cube2.boxPrint();

	}

}
