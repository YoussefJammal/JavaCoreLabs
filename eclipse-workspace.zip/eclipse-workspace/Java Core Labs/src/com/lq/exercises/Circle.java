package com.lq.exercises;

public class Circle extends Shape implements TwoDimensional {
	
	// Attributes
	private double radius;
	
	// Setters and Getters
	public void setRadius(double newRadius) {
		radius = newRadius;
	}
	
	public double getRadius() {
		return radius;
	}
	
	// Constructor
	public Circle(String newName, String newColor, double newRadius) {
		super(newName, newColor);
		setRadius(newRadius);
	}
	
	// Areas and parameter
	public double getArea() {
		return (Math.PI)*Math.pow(radius, 2);
	}
	
	public double getPerimeter() {
		return 2 * (Math.PI)*radius;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Shape [radius=");
		builder.append(getRadius());
		builder.append(", color=");
		builder.append(super.getColor());
		builder.append(", name=");
		builder.append(super.getName());
		builder.append("]");
		return builder.toString();
	}
	

}