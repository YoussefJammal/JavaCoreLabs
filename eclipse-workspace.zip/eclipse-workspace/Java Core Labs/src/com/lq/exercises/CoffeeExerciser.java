package com.lq.exercises;

public class CoffeeExerciser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coffee coffee = null;
		
		try {
			coffee = new Coffee(125);
		} catch(TooHotException the) {
			System.out.println(the.getMessage());
		} finally {
			System.out.println("The coffee temperature is set to " + coffee.getTemperature());
		}
	}

}
