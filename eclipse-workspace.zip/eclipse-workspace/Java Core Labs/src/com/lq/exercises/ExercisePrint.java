package com.lq.exercises;

public class ExercisePrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Shape[] s = new Shape[5];
		s[0] = new Rectangle("rectangle1", "green", 1, 1);
		s[1] = new Square("square1", "green", 1);
		s[2] = new Cube("cube1", "green", 1);
		s[3] = new Box("box1", "green", 1,1,1);
		s[4] = new Circle("circle1", "green", 1);
		
		for(Shape k:s) {
			System.out.println(k.toString());
		}

	}

}
