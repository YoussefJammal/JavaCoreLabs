package com.lq.exercises;

public class TooHotException extends Exception {
	// Variable declaration
	private String stringMessage;
	
	// Constructor
	public TooHotException(){
		// initiate default exception
		super();
	}
	public TooHotException(String newStringMessage) {
		super(newStringMessage);
		stringMessage = newStringMessage;
	}

}
