package com.lq.exercises;

public class Coffee {
	// Variables
	private int temperature;
	
	// Setters and getters
	public int getTemperature() {
		return temperature;
	}
	
	public void setTemperature(int newTemperature) throws TooHotException {
		if(newTemperature > 120) {
			throw new TooHotException("this coffee is piping hot!");
		}
		else {
			temperature = newTemperature;
		}
	}
	
	// Constructors
	public Coffee() {
		// Default constructor
	}
	public Coffee(int newTemperature) throws TooHotException {
		setTemperature(newTemperature);
	}
	
}
