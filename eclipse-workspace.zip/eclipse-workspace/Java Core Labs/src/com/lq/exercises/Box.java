package com.lq.exercises;


public class Box extends Shape implements ThreeDimensional {
	
	// Height declaration with its setter and getter
	private double height;
		public double getHeight() {
			return height;
		}
		public void setHeight(double newHeight) {
			if(newHeight <= 0) {
				negativeValues();
			}
			else {
				height = newHeight;
				update();
			}
		}
	// Width declaration with its setter and getter
	private double width;
		public double getWidth() {
			return width;
		}
		public void setWidth(double newWidth) {
			if(newWidth <= 0) {
				negativeValues();
			}
			else {
				width = newWidth;
				update();
			}
		}
	
	// Length declaration with its setter and getter
	private double length;
		public double getLength() {
			return length;
		}
		public void setLength(double newLength) {
			if(newLength <= 0) {
				negativeValues();
			}
			else {
				length = newLength;
				update();
			}
		}
	// Create the box constructor
	Box(String newName, String newColor, double h, double w, double l){
		super(newName, newColor);
		setHeight(h);
		setWidth(w);
		setLength(l);
		update();
	}
	// Create the box constructor only for cubes
	Box(String newName, String newColor, double c){
		this(newName, newColor, c, c, c);
	}
	
	// Calculate the volume and create a getter
	private double volume;
		private void setVolume(double newVolume) {
			volume = newVolume;
		}
		@Override
		public double getVolume() {
			return volume;
		}
	
	// Calculate the surface area and create a getter
	private double surfaceArea;
		private void setSurfaceArea(double newSurfaceArea) {
			surfaceArea = newSurfaceArea;
		}
		@Override
		public double getSurfaceArea() {
			return surfaceArea;
		}
	
		
	//Follow-up on volume and surface area
	protected void update() {
		setVolume(width * height * length);
		setSurfaceArea(2 * width * height + 2 * width * length + 2 * length * height);
	}
	
	// Printing an error free box
	public void boxPrint() {
			System.out.println("Length = " + length);
			System.out.println("Width = " + width);
			System.out.println("Height = " + height);
			System.out.println("Volume = " + volume);
			System.out.println("Surface Area = " + surfaceArea);
	}
	
	protected void negativeValues() {
		System.out.println("No negative values can be taken in, reverting back to old values");
	}
}

