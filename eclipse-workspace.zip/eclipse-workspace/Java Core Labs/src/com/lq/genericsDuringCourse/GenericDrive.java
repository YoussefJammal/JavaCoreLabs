package com.lq.genericsDuringCourse;

public class GenericDrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stacks<Integer> arrayList = new GenericApp<>();
		
		arrayList.push(50);
		
		System.out.print(arrayList.pop());

	}

}
