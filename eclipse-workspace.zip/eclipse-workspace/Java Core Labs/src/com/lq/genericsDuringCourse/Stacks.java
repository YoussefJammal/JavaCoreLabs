package com.lq.genericsDuringCourse;

public interface Stacks<E> {
	
	public void push(E element);
	
	public E pop();

}
