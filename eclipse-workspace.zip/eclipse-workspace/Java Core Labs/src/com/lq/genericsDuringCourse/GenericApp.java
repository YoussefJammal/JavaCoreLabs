package com.lq.genericsDuringCourse;

import java.util.ArrayDeque;
import java.util.Deque;

public class GenericApp<E> implements Stacks<E> {
	
	private Deque<E> object;
	
	public GenericApp() {
		object = new ArrayDeque<E>();
	}

	@Override
	public void push(E element) {
		// TODO Auto-generated method stub
		
		object.push(element);
		
	}

	@Override
	public E pop() {
		// TODO Auto-generated method stub
		return object.pop();
	}
	
}