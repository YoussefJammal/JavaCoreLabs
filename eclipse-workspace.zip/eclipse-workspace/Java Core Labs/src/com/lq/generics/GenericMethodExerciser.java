package com.lq.generics;

public class GenericMethodExerciser {
	
	public static void main(String[] args) {
		Integer[] integerArray = {1,2,3,4,5};
		GenericMethod.printArray(integerArray);

	}
	
}
