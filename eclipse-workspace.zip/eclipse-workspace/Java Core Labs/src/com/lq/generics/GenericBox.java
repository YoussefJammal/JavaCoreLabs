package com.lq.generics;

public class GenericBox<T> {
	
	private T t;

	public T getT() {
		return t;
	}

	public void setT(T newT) {
		t = newT;
	}
	

}
