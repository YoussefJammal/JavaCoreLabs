package com.lq.generics;

public class MaximumExerciser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double x = Maximum.maximum(15.5, 30.0, 40.0);
		
		System.out.print(x);

	}

}
