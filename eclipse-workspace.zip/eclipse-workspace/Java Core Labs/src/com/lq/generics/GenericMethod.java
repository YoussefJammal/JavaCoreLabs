package com.lq.generics;

public class GenericMethod<E> {
	
	public static <E> void printArray(E[] inputArray) {
		for(E element : inputArray) {
			System.out.print(" "+element);
		}
		System.out.println();
	}
}
