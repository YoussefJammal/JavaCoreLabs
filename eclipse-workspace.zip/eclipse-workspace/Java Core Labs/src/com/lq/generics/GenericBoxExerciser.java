package com.lq.generics;

public class GenericBoxExerciser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GenericBox<String> stringBox = new GenericBox<>();
		GenericBox<Integer> integerBox = new GenericBox<>();
		
		stringBox.setT("hello");
		
		integerBox.setT(25);
		
		System.out.println("String value: " + stringBox.getT());
		System.out.println("Integer value: " + integerBox.getT());

	}

}
