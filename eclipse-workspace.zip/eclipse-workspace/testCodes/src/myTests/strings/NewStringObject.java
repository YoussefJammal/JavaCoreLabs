package myTests.strings;

public class NewStringObject {

	public static void main(String[] args) {
		// This is to see what an empty string prints out
		System.out.println(1);
		String str = new String();
		System.out.println(str);
		System.out.println(1);
		System.out.println(1);
	}

}
