package myTests.Static.Attributes;

public class Attributes {
	
	Attributes(){ }
	
	private static int RANDOM_CONSTANT;
	
	public int getRANDOM_CONSTANT() {
		return RANDOM_CONSTANT;
	}

	public void setRANDOM_CONSTANT(int newRandomConstant) {
		RANDOM_CONSTANT = newRandomConstant;
	}
}
