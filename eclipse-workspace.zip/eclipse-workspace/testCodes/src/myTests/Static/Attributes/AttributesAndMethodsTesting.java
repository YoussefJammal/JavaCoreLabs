package myTests.Static.Attributes;

public class AttributesAndMethodsTesting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Attributes att1 = new Attributes();
		Attributes att2 = new Attributes();
		
		att1.setRANDOM_CONSTANT(10);
		
		System.out.println(att1.getRANDOM_CONSTANT());
		System.out.println(att2.getRANDOM_CONSTANT());
		
		att2.setRANDOM_CONSTANT(15);
		
		System.out.println(att1.getRANDOM_CONSTANT());
		System.out.println(att2.getRANDOM_CONSTANT());

	}

}
