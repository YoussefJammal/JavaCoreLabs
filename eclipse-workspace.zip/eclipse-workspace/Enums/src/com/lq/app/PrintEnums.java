package com.lq.app;

import com.lq.enums.TirePressures;

public class PrintEnums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TirePressures tp = TirePressures.valueOf("RR");
		tp.overridePressure(22);
		
		for(TirePressures t : TirePressures.values()) {
			System.out.println("The " + t.getName() + " tire has a pressure of " + t.getPressure() + " pounds");
		}

	}

}
