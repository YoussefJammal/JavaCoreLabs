package com.lq.app;
import java.util.ArrayList;
/*
@SuppressWarnings("all")
*/

/*
@SuppressWarnings("unused")
*/

/*
@author student
*/

@SuppressWarnings("rawtypes")


public class AnnotationExamples {
	ArrayList arrayList = new ArrayList();
	int k = 0;
	
	@SuppressWarnings({"unused", "unchecked"})
	public void method1() {
		arrayList.add(new String());
		int j = 0;
		int i = 0;
	}
	
	@SuppressWarnings("unused")
	public String toString() {
		int i = 0;
		return super.toString();
	}

}
